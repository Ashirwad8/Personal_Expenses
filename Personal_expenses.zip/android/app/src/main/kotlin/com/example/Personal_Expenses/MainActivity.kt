package com.example.Personal_Expenses

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
